const products = [
  {
    id: 1,
    name: "Laptop",
    price: 60000,
    image: "https://m.media-amazon.com/images/I/71TPda7cwUL._SL1500_.jpg"
  },
  {
    id: 2,
    name: "Smartphone",
    price: 25000,
    image: "https://m.media-amazon.com/images/I/61bK6PMOC3L._SL1500_.jpg"
  },
  {
    id: 3,
    name: "Headphones",
    price: 3000,
    image: "https://m.media-amazon.com/images/I/61CGHv6kmWL._SL1500_.jpg"
  },
  {
    id: 4,
    name: "Smart Watch",
    price: 2000,
    image: "https://m.media-amazon.com/images/I/61ZjlBOp+rL._SL1500_.jpg"
  }
];

export default products;